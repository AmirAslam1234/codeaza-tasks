from bs4 import BeautifulSoup
from lxml import etree
import requests

from flask import Flask, render_template,  request
import pymysql
pymysql.install_as_MySQLdb()


class Movies(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(300), nullable=True, default='none')
    se = db.Column(db.Integer, nullable=True, default=0)
    le = db.Column(db.Integer, nullable=True, default=0)
    size = db.Column(db.String(20), nullable=True, default='0 MB')
    uploader = db.Column(db.String(50), nullable=True, default='none')
    link = db.Column(db.String(200), nullable=True, default='not get link')


@app.route("/movies")
def movie():
    return render_template('movies.html')


def getCategory(url):
    r = requests.get(url)

    htmlcontent = r.content

    soup = BeautifulSoup(htmlcontent, "html.parser")
    dom = etree.HTML(str(soup))

    test1 = soup.find('strong', text='Genre ')

    test2 = soup.find('span', text='Genre')

    if(test1):
        return test1.next_sibling
    elif(test2):
        return dom.xpath('//*[@id="description"]/p[2]/text()[7]')
    else:
        return 'no category'


@app.route("/movies1", methods=['GET', 'POST'])
def movies():
    if request.method == 'POST':
        url = request.form.get('link')
        number = request.form.get('no')
        number = int(number)
        r = requests.get(url)
        htmlContent = r.content
        soup = BeautifulSoup(htmlContent, "html.parser")
        dom = etree.HTML(str(soup))
        se = []
        le = []
        name = []
        size = []
        uploader = []
        link = []
        category = []

        for i in range(1, number + 1):
            link_data = dom.xpath(
                '/html/body/main/div/div/div[4]/div/table/tbody/tr['+str(i)+']/td[1]/a[2]/@href')[0]
            actual_link = 'https://1337x.to' + link_data

            se_data = dom.xpath('/html/body/main/div/div/div[4]/div/table/tbody/tr['+str(
                i)+']/td[2]')[0].text
            le_data = dom.xpath(
                '/html/body/main/div/div/div[4]/div/table/tbody/tr['+str(i)+']/td[3]')[0].text
            name_data = dom.xpath(
                '/html/body/main/div/div/div[4]/div/table/tbody/tr['+str(i)+']/td[1]/a[2]')[0].text
            size_data = dom.xpath(
                '/html/body/main/div/div/div[4]/div/table/tbody/tr['+str(i)+']/td[5]')[0].text
            uploader_data = dom.xpath(
                '/html/body/main/div/div/div[4]/div/table/tbody/tr['+str(i)+']/td[6]/a')[0].text
            se.append(se_data)
            le.append(le_data)
            size.append(size_data)
            name.append(name_data)
            uploader.append(uploader_data)
            link.append(actual_link)

        for i in range(0, number):
            category_data = getCategory(link[i])
            category.append(category_data)
            new_data = Movies(se=se[i], le=le[i], size=size[i],
                              uploader=uploader[i], name=name[i], link=link[i], category=category[i])
            db.session.add(new_data)
            db.session.commit()

        return render_template('movies.html')
